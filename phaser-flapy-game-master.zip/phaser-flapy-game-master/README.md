# phaser-flapy-game
Look a like  flapy bird game. Using phaser.io
